import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
from tests.tests import tests  # tests papkadan import

# 🔑 Token va kanal
TOKEN = "8195337626:AAH6EVM49qscyePqb13qUTm54sy5RIqyoqI"
CHANNEL_USERNAME = "@Geografiya_attestatsiya1"

bot = telebot.TeleBot(TOKEN)

# ➕ Kanalga obuna bo‘lishni tekshirish
def check_subscription(user_id):
    try:
        status = bot.get_chat_member(CHANNEL_USERNAME, user_id).status
        return status in ["member", "administrator", "creator"]
    except:
        return False

# 🚀 Start komandasi
@bot.message_handler(commands=["start"])
def send_welcome(message):
    if not check_subscription(message.from_user.id):
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("📢 Kanalga qo‘shilish", url=f"https://t.me/{CHANNEL_USERNAME[1:]}"))
        bot.send_message(message.chat.id, "Botdan foydalanish uchun kanalga obuna bo‘ling!", reply_markup=markup)
        return

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🧮 Mantiqiy testlar", callback_data="logic_tests"))
    bot.send_message(message.chat.id, "📚 Sinfni tanlang:", reply_markup=markup)

# 📌 Callback tugmalar
@bot.callback_query_handler(func=lambda call: True)
def handle_callback(call):
    if call.data == "logic_tests":
        for i, test in enumerate(tests[:5], 1):  # birinchi 5 ta test chiqaramiz
            question = test["savol"]
            options = test["variantlar"]
            markup = InlineKeyboardMarkup()
            for opt in options:
                markup.add(InlineKeyboardButton(opt, callback_data=f"answer_{i}_{opt}"))
            bot.send_message(call.message.chat.id, f"❓ {question}", reply_markup=markup)

    elif call.data.startswith("answer_"):
        _, idx, chosen = call.data.split("_", 2)
        idx = int(idx) - 1
        correct = tests[idx]["javob"]
        if chosen == correct:
            bot.send_message(call.message.chat.id, "✅ To‘g‘ri javob!")
        else:
            bot.send_message(call.message.chat.id, f"❌ Noto‘g‘ri. To‘g‘ri javob: {correct}")

# ▶️ Botni ishga tushirish
bot.polling(none_stop=True)
